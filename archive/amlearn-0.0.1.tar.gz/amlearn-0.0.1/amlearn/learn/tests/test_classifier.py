from amlearn.utils.basetest import AmLearnTest


class TestClassifier(AmLearnTest):
    # def test_
    pass