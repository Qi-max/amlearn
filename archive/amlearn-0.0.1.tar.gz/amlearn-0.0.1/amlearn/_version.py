# -*- coding: utf-8 -*-

"""Version of the amlearn library.
"""

__version__ = '0.0.1'
