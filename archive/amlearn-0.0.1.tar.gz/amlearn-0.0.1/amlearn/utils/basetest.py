import unittest


class AmLearnTest(unittest.TestCase):
    pass